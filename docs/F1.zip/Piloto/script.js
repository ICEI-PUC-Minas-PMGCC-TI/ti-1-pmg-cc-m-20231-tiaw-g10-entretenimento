var imagem = document.querySelector('.pilotos');


      function redirecionar(url) {
  window.location.href = url;
}
function mostrarPopup() {
			document.getElementById("popup").style.display = "block";
		}




