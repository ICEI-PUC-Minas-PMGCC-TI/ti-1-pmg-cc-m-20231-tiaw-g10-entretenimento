const button = document.querySelector('#button')
const popup = document.querySelector('.wrapper')

button.addEventListener('click', () => {
  popup.style.display = 'block'

})
popup.addEventListener('click', () => {
  popup.style.display = 'none'

})


const button2 = document.querySelector('#button2')
const popup2 = document.querySelector('.wrapper2')

button2.addEventListener('click', () => {
  popup2.style.display = 'block'

})
popup2.addEventListener('click', () => {
  popup2.style.display = 'none'

})



const button3 = document.querySelector('#button3')
const popup3 = document.querySelector('.wrapper3')

button3.addEventListener('click', () => {
  popup3.style.display = 'block'

})
popup3.addEventListener('click', () => {
  popup3.style.display = 'none'

})

const button4 = document.querySelector('#button4')
const popup4 = document.querySelector('.wrapper4')

button4.addEventListener('click', () => {
  popup4.style.display = 'block'

})
popup4.addEventListener('click', () => {
  popup4.style.display = 'none'

})

const button5 = document.querySelector('#button5')
const popup5 = document.querySelector('.wrapper5')

button5.addEventListener('click', () => {
  popup5.style.display = 'block'

})
popup5.addEventListener('click', () => {
  popup5.style.display = 'none'

})

const button6 = document.querySelector('#button6')
const popup6 = document.querySelector('.wrapper6')

button6.addEventListener('click', () => {
  popup6.style.display = 'block'

})
popup6.addEventListener('click', () => {
  popup6.style.display = 'none'

})

const button7 = document.querySelector('#button7')
const popup7 = document.querySelector('.wrapper7')

button7.addEventListener('click', () => {
  popup7.style.display = 'block'

})
popup7.addEventListener('click', () => {
  popup7.style.display = 'none'

})

const button8 = document.querySelector('#button8')
const popup8 = document.querySelector('.wrapper8')

button8.addEventListener('click', () => {
  popup8.style.display = 'block'

})
popup8.addEventListener('click', () => {
  popup8.style.display = 'none'

})

const button9 = document.querySelector('#button9')
const popup9 = document.querySelector('.wrapper9')

button9.addEventListener('click', () => {
  popup9.style.display = 'block'

})
popup9.addEventListener('click', () => {
  popup9.style.display = 'none'

})
const button10 = document.querySelector('#button10')
const popup10 = document.querySelector('.wrapper10')

button10.addEventListener('click', () => {
  popup10.style.display = 'block'

})
popup10.addEventListener('click', () => {
  popup10.style.display = 'none'

})
const button11 = document.querySelector('#button11')
const popup11 = document.querySelector('.wrapper11')

button11.addEventListener('click', () => {
  popup11.style.display = 'block'

})
popup11.addEventListener('click', () => {
  popup11.style.display = 'none'

})
const button12 = document.querySelector('#button12')
const popup12 = document.querySelector('.wrapper12')

button12.addEventListener('click', () => {
  popup12.style.display = 'block'

})
popup12.addEventListener('click', () => {
  popup12.style.display = 'none'

})




function redirecionar() {
  window.location.href = "../circuitos/index.html"
}